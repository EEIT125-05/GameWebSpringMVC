package com.web.game.contest.dao;

import java.util.List;

import com.web.game.contest.model.GameList;

public interface GameListDAO {
	
	List<GameList> selectGameList();

}
